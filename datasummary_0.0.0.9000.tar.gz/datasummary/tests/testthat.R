library(testthat)
library(datasummary)

test_check("datasummary")
