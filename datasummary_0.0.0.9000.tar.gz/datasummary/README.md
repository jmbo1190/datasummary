# datasummary

A demo package to summarize numeric columns from a data frame.

## Install
```
remotes::install_github("jmbo1190/datasummary")
```
Restart R may be needed.

<!-- badges: start -->
  [![R](https://github.com/jmbo1190/datasummary/actions/workflows/r.yml/badge.svg)](https://github.com/jmbo1190/datasummary/actions/workflows/r.yml)
  [![R-CMD-check](https://github.com/jmbo1190/datasummary/workflows/R-CMD-check/badge.svg)](https://github.com/jmbo1190/datasummary/actions)
<!-- badges: end -->
